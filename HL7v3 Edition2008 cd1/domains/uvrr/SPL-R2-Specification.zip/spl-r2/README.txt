This is the SPL release 2 package

Contents and Roadmap

README.txt - this file

Specification Document (Normative Content)

spl-r2.doc - Microsoft Word
spl-r2.pdf - PDF

Hirarchical Definition (Normative)

PORR_HD050024.xls - as Excel table
PORR_HD050024.hmd - as an XML file from RoseTree
PORR_HD050024.mif - as an MIF XML file

  The MIF is the new HL7 Model Interchange Format. The .hmd file
  is an older format exported from the design tools. The only
  human readable rendition is the Excel file.

Refined Message Information Model (RMIM)

PORR_RM050024.vsd - for Visio RMIM design tool
PORR_RM050024.gif - a bitmap image

XML Schemas

PORR_MT050024.xsd - The SPL release 2 full schema 
(sometimes called "release 2b")
PORR_MT050016.xsd - The SPL schema on the level of release 1
(sometimes called "release 2a")

NarrativeBlock.xsd - Narrative block schema (for text)
template-instantiations.xsd - data types schema (part 1)
datatypes.xsd - data types schema (part 2)
voc.xsd - structural vocabulary schema
xml.xsd - the XML namespace schema

Examples for SPL 2 full release (aka "2b")

capoten.xml - the example label
spl2.xsl - the rendering stylesheet conformant to the 
  Physicians' Labeling Rule NPRM of 2000.
spl2-sections.xml - section metadata used by the stylesheet
spl2.css - CSS for rendering style

Examples for SPL 2 at level of release 1 (aka "2a")

xalatan.xml - the example label
xalatan-01.jpg - image used in the example label
spl.xsl - old rendering stylesheet
spl.css - old CSS for rendering styles

Supporting Files For XML Display Stylesheet Mode

xml-verbatim.xsl - XML display stylesheet
xml-verbatim.css - CSS for display styles
xml-verbatim.js - mouse-click functions


